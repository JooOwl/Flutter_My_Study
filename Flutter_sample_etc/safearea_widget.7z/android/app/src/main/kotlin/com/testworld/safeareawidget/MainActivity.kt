package com.testworld.safeareawidget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
