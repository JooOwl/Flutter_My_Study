package com.testworld.scrollingdetection

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
