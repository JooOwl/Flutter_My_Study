package com.testworld.tabs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
