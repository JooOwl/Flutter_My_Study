package com.testworld.tipcalculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
