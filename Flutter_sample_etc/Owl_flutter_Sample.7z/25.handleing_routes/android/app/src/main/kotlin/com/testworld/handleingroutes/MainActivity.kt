package com.testworld.handleingroutes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
