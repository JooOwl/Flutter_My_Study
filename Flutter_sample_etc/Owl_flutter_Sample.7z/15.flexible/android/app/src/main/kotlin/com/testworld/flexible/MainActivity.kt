package com.testworld.flexible

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
