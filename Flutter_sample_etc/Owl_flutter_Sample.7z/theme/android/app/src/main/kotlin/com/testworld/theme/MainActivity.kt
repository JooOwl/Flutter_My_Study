package com.testworld.theme

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
