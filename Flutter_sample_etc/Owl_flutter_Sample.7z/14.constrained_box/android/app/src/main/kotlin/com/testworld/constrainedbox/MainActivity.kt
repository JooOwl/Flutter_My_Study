package com.testworld.constrainedbox

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
