package com.testworld.alertdialog

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
