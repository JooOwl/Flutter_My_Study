package com.testworld.slivers

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
