package com.testworld.animatetheme

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
