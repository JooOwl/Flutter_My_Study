package com.testworld.snackbar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
