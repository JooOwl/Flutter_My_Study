package com.testworld.amimateicon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
