class ContactModal {
  final String fullName;
  final String email;

  const ContactModal({this.fullName, this.email});
}
