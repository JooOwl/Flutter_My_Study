package com.testworld.flutterapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
