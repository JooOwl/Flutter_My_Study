import 'package:flutter/material.dart';

// MyApp을 시작 위젯으로 설정하여 앱을 실행
void main() => runApp(MyApp());

// 앱의 시작점에 해당하는 위젯
class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    // 매트리얼앱을 생성하여 반환
    return MaterialApp(
        title: 'Flutter Layout Demo', // 앱의 타이틀
        theme: ThemeData( // 앱의 테마 설정
          primarySwatch: Colors.red,  // 주요 테마 색상
        ),
        // 홈 설정. 홈은 메트리얼앱의 시작점
        home:Scaffold(
          appBar: AppBar(
            title: Text("Flutter layout demo"),
          ),
          body: Center(
            child: Text("Hello World"),
          ),
        )
    );
  }
}