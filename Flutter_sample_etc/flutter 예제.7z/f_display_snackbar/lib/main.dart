import 'package:flutter/material.dart';

void main() => runApp(SnackBarDemo());

class SnackBarDemo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // MaterialApp 생성/반환
    return MaterialApp(
      title: 'Snackbar Demo',
      // 홈으로 Scaffold을 직접 구현
      home: Scaffold(
        appBar: AppBar(title: Text('SnackBar Demo')),
        // SncacBarpage 클래스 호출
        body: SnackBarPage(),
      ),
    );
  }
}

// 초기 스크린의 body를 구성
class SnackBarPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      // 화면 중앙에 RaisedButton 추가
      child: RaisedButton(
        // RaisedButton에 텍스트 추가
        child: Text('Show SnackBar'),
        // RaisedButton을 누르면 호출
        onPressed: () {
          // 스낵바 생성
          final snackbar = SnackBar(
            // 컨텐트 구성. 텍스를 주입
            content: Text('Yay! A SncackBar!'),
            // 액션 구입
            action: SnackBarAction(
              // 스낵바에 label 추가
              label: 'Undo',
              // 스낵바에 label을 누를 때 호출
              onPressed: () {
                // Some code to undo the change.
              },
            ),
          );
          
          // 생성한 스낵바를 노출. 화면 하단에 스낵바가 출력됨
          Scaffold.of(context).showSnackBar(snackbar);
        },
      ),
    );
  }
}