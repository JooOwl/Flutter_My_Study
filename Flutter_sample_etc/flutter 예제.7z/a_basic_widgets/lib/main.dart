import 'package:flutter/material.dart';

// 메인 함수. 프로그램의 시작점
void main(){

  // MaterialApp을 실행. MaterialApp은 Flutter가 제공하는 material 디자인을 사용하는 앱을 의미함
  runApp(MaterialApp(
    title: "My app",
    home: MyScaffold(), // 앱의 기본 경로를 위한 위젯
  ));
}

class MyScaffold extends StatelessWidget{

  @override
  Widget build(BuildContext context) {

    // 매트리얼을 생성하여 반환. 매트리얼은 매트리얼앱을 구성하는 기본 단위
    return Material(

      // 매트리얼에 컬럼을 자식으로 추가. 컬럼은 수직적인 구성을 가짐
      child: Column(
        // 컬럼에 위젯(MyAppBar과 Expanded)를 자식들로 추가함
        children: <Widget>[

          // 첫번째 자식으로 MyAppBar를 추가
          MyAppBar(
            title: Text(
              "Example title",
              style: Theme.of(context).primaryTextTheme.title,
            ),
          ),

          // 두번째 자식으로 Expanded를 추가. MyAppBar를 제외한 영역을 차지
          Expanded(
            // Expanded의 자식으로 Center를 추가
            child: Center(
              // Center의 자식으로 Text를 추가
              child: Text("Hello, world!"),
            ),
          )
        ],
      ),
    );
  }
}

class MyAppBar extends StatelessWidget{

//  생성자. 생성시 전달받은 값을 타이틀로 할당당
  MyAppBar({this.title});

  // 타이틀 위젯을 선언
  final Widget title;

  @override
  Widget build(BuildContext context) {

    // 컨테이너를 구성하여 반환. 컨테이너는 사각형 모양의 앨리먼트들을 생성할 수 있음
    return Container(
      height: 70.0, // 컨테이너의 높이
      padding: const EdgeInsets.symmetric(horizontal: 8.0), // 컨테이너 내부의 패딩값
      decoration: BoxDecoration(color: Colors.blue), // 컨테이너를 파란색으로 꾸밈

      child: Row(   // 컨테이너의 열(row)을 자식(child)으로 추가함
        children: <Widget>[   // IconButton, Expended, IconButton을 열의 자식들로 추가함

          // 첫번째 자식으로 IconButton을 추가
          IconButton(
            icon: Icon(Icons.menu), // 메뉴 아이콘
            tooltip: "Navigation menu", // 메뉴 아이콘을 누르고 있으면 표시될 문구
            onPressed: null,  // 눌렀을 때 아무 기능 없음
          ),

          // 두번째 자식으로 Expanded를 추가
          // Expanded는 다른 자식들이 차지하고 있지 않은 모든 영역을 자신의 영역(너비)로 가짐
          Expanded(
            child: title, // 타이틀 위젯을 자식으로 등록
          ),

          // 세번째 자식으로 IconButton을 추가
          IconButton(
            icon: Icon(Icons.search), // 검색 아이콘
            tooltip: "Search",
            onPressed: null,
          )
        ],
      ),
    );
  }
}