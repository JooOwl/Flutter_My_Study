import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'Retrieve Text Input', home: MyCustomForm());
  }
}

class MyCustomForm extends StatefulWidget {
  @override
  _MyCustomFormState createState() => _MyCustomFormState();
}

class _MyCustomFormState extends State<MyCustomForm> {
  // TextEditingController 인스턴스를 필드에 저장
  final myController = TextEditingController();

  @override
  void dispose() {
    myController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Retrive Text Input'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          // 텍스트필드의 controller 항목에 TextEditingController 인스턴스 연결
          child: TextField(
            controller: myController,
          ),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            // 버튼이 눌리면 다이얼로그 출력
            return showDialog(
                context: context,
                builder: (context) {
                  return AlertDialog(
                    // myController의 현재 텍스트 값을 컨텐트로 AlertDialog 출력
                    content: Text(myController.text),
                  );
                });
          },
          tooltip: 'Show me the value!',
          child: Icon(Icons.text_fields),
        ));
  }
}