package com.testworld.addmeterialtouchripples

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
