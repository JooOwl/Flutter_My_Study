package com.testworld.placefloatingbarlist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
