package com.testworld.differenttypesitems

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
