package com.testworld.worklonglists

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
