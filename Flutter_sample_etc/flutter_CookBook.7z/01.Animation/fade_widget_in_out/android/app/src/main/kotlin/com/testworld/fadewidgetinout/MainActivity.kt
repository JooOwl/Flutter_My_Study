package com.testworld.fadewidgetinout

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
