package com.testworld.animatedcontainer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
