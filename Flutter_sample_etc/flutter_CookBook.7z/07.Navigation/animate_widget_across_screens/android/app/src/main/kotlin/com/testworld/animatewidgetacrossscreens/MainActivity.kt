package com.testworld.animatewidgetacrossscreens

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
