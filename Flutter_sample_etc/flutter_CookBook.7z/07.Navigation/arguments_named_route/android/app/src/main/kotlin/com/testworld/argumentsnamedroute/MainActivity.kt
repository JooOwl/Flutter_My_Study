package com.testworld.argumentsnamedroute

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
