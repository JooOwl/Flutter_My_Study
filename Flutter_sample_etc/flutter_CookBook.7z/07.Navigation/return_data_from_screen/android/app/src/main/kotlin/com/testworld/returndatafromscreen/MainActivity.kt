package com.testworld.returndatafromscreen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
