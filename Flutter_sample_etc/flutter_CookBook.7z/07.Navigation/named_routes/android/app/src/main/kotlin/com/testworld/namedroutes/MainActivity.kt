package com.testworld.namedroutes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
