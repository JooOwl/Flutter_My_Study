package com.testworld.screenandback

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
