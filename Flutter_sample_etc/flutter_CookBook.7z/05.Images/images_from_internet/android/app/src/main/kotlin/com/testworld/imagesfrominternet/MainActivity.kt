package com.testworld.imagesfrominternet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
