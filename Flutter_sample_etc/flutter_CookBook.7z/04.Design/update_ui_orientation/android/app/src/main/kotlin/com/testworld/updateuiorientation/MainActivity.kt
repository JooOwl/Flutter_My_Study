package com.testworld.updateuiorientation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
