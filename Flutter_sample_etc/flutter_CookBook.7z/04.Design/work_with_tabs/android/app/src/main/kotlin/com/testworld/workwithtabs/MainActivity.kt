package com.testworld.workwithtabs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
